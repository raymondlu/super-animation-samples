//
//  tmpSuperAnimSamples2AppController.h
//  tmpSuperAnimSamples2
//
//  Created by 卢 敬慧 on 12/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
